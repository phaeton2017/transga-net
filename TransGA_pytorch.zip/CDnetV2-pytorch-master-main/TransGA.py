import cv2
import numpy as np
import torch
import torch.nn as nn
from torchvision import models
import torch.nn.functional as F
from torch.nn import ReLU
from model.unet_model import UNet
# import resnet_model
from model.backbone import mit_b4
from model.resnet_model import *
from model.segformer import SegFormer, SegFormerHead
from model.sync_batchnorm import SynchronizedBatchNorm2d
from model.MultiScaleFusion import MultiScaleFusion
from torchvision import transforms, utils
from torchvision.transforms import Resize

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
t_resize = Resize([384, 384])
stage1_resize = Resize([12, 12])
stage2_resize = Resize([24, 24])

class Multi_Attention(nn.Module):
    def __init__(self):
        super(Multi_Attention, self).__init__()

        # 定义模块中用到的各个层
        self.conv1d_list = nn.ModuleList([
            nn.Conv1d(in_channels=1, out_channels=1, kernel_size=9, dilation=d, padding=p)
            for (d, p) in zip([1, 2, 4, 8], [4, 8, 16, 32])
        ])
        self.relu = nn.ReLU()
        self.linear = nn.Linear(4, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 连接整合输入特征图
        map1 = torch.cat(x, dim=1)
        # 进行2D全局池化
        global_pool = nn.functional.adaptive_avg_pool2d(map1, (1, 1))
        # 进行Transpose和Squeeze
        transposed = global_pool.permute(0, 2, 3, 1).squeeze(dim=1)
        # 进行一维卷积操作
        conv1d_outputs = [conv(transposed) for conv in self.conv1d_list]
        conv1d_results = torch.cat(conv1d_outputs, dim=1)

        # 进行转置操作
        transposed_conv = conv1d_results.permute(0, 2, 1)

        # 进行ReLU操作
        relu_output = self.relu(transposed_conv)

        # 进行Linear操作
        linear_output = self.linear(relu_output)

        # 进行Sigmoid操作
        sigmoid_output = self.sigmoid(linear_output)

        # 进行unsqueeze操作
        unsqueezed = sigmoid_output.unsqueeze(-1)

        output = unsqueezed * map1

        return output



class CascadeFusion (nn.Module):
    def __init__(self, in_channels):
        super(CascadeFusion, self).__init__()

        # 定义各个操作所需要的模块
        self.conv1_map1 = nn.Conv2d(in_channels=256, out_channels=256, kernel_size=3, padding=2, dilation=2)
        self.bn1_map1 = nn.BatchNorm2d(256)
        self.relu1_map1 = nn.ReLU(inplace=True)

        self.conv1_map2 = nn.Conv2d(in_channels=in_channels, out_channels=256, kernel_size=3, padding=1)
        self.bn1_map2 = nn.BatchNorm2d(256)
        self.relu1_map2 = nn.ReLU(inplace=True)

        self.conv_concat = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=5, padding=4, dilation=2)
        self.bn_concat = nn.BatchNorm2d(256)
        self.relu_concat = nn.ReLU(inplace=True)

        self.conv_final = nn.Conv2d(in_channels=256, out_channels=256, kernel_size=3, padding=1)
        self.bn_final = nn.BatchNorm2d(256)
        self.relu_final = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

        # self.conv1_map2 = nn.Conv2d(in_channels=128, out_channels=256, kernel_size=3, padding=1)

    def forward(self, map1, map2):

        # in_channels = map2.shape[1]

        # 对 map1 的操作
        map1 = nn.functional.interpolate(map1, scale_factor=2, mode='bilinear', align_corners=False)
        x_low = self.relu1_map1(self.bn1_map1(self.conv1_map1(map1)))

        # 对 map2 的操作
        x_high = self.relu1_map2(self.bn1_map2(self.conv1_map2(map2)))

        # 执行concat操作
        concat_features = torch.cat((x_low, x_high), dim=1)
        concat_output = self.relu_concat(self.bn_concat(self.conv_concat(concat_features)))

        # 使用Sigmoid获得x_ga
        x_ga = self.sigmoid(self.relu_final(self.bn_final(self.conv_final(concat_output))))

        # 分支1：x_ga与x_low做Hadamard积得到output1
        output1 = x_ga * x_low

        # 分支2：(1 - x_ga)与x_high做Hadamard积得到output2
        output2 = (1 - x_ga) * x_high

        # 将output1和output2相加得到模块的结果
        module_output = output1 + output2

        return module_output

class Fusion_dsc(nn.Module):
    def __init__(self):
        super(Fusion_dsc, self).__init__()

    def forward(self, input1, input2, input3):

        # 对 map1 的操作
        conv1_map1 = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=3, padding=2, dilation=2)
        bn1_map1 = nn.BatchNorm2d(256)
        relu1_map1 = nn.ReLU(inplace=True)
        x_low = relu1_map1(bn1_map1(conv1_map1(input1)))

        # 对 map2 的操作
        conv1_map2 = nn.Conv2d(in_channels=1, out_channels=256, kernel_size=3, padding=1)
        bn1_map2 = nn.BatchNorm2d(256)
        relu1_map2 = nn.ReLU(inplace=True)
        x_high = relu1_map2(bn1_map2(conv1_map2(input2)))

        x_output12 = x_low + x_high

        # 对 map3 的操作
        # 上采样操作
        map12 = nn.functional.interpolate(x_output12, scale_factor=2, mode='bilinear', align_corners=False)
        conv1_map3 = nn.Conv2d(in_channels=320, out_channels=256, kernel_size=3, padding=1)
        bn1_map2 = nn.BatchNorm2d(256)
        relu1_map2 = nn.ReLU(inplace=True)
        x_in3 = relu1_map2(bn1_map2(conv1_map3(input3)))

        x_output = map12 + x_in3
        # 特征图相加操作



        return x_output

class DiffNet(nn.Module):
    def __init__(self, in_ch, inc_ch):
        super(DiffNet, self).__init__()

        self.conv0 = nn.Conv2d(in_ch, inc_ch, 3, padding=1)

        self.conv1 = nn.Conv2d(inc_ch, 64, 3, padding=1)
        self.bn1 = SynchronizedBatchNorm2d(64)
        self.relu1 = nn.ReLU(inplace=True)

        self.pool1 = nn.MaxPool2d(2, 2, ceil_mode=True)

        self.conv2 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn2 = SynchronizedBatchNorm2d(64)
        self.relu2 = nn.ReLU(inplace=True)

        self.pool2 = nn.MaxPool2d(2,2,ceil_mode=True)

        self.conv3 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn3 = SynchronizedBatchNorm2d(64)
        self.relu3 = nn.ReLU(inplace=True)

        self.pool3 = nn.MaxPool2d(2, 2, ceil_mode=True)

        self.conv4 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn4 = SynchronizedBatchNorm2d(64)
        self.relu4 = nn.ReLU(inplace=True)

        self.pool4 = nn.MaxPool2d(2, 2, ceil_mode=True)


        self.conv5 = nn.Conv2d(64, 64, 3, padding=1)
        self.bn5 = SynchronizedBatchNorm2d(64)
        self.relu5 = nn.ReLU(inplace=True)


        self.conv_d4 = nn.Conv2d(128, 64, 3, padding=1)
        self.bn_d4 = SynchronizedBatchNorm2d(64)
        self.relu_d4 = nn.ReLU(inplace=True)

        self.conv_d3 = nn.Conv2d(128, 64, 3, padding=1)
        self.bn_d3 = SynchronizedBatchNorm2d(64)
        self.relu_d3 = nn.ReLU(inplace=True)

        self.conv_d2 = nn.Conv2d(128, 64, 3, padding=1)
        self.bn_d2 = SynchronizedBatchNorm2d(64)
        self.relu_d2 = nn.ReLU(inplace=True)

        self.conv_d1 = nn.Conv2d(128, 64, 3, padding=1)
        self.bn_d1 = SynchronizedBatchNorm2d(64)
        self.relu_d1 = nn.ReLU(inplace=True)

        self.conv_d0 = nn.Conv2d(64, 1, 3, padding=1) #2
        self.upscore2 = nn.Upsample(scale_factor=2, mode='bilinear',align_corners=False)


    def forward(self,x):
        # x = Resize([4, 1, 320, 320])
        hx = x
        # print('x:', hx.shape)
        hx = self.conv0(hx)
        # print('conv0:', hx.shape)
        hx1 = self.relu1(self.bn1(self.conv1(hx)))
        # print('relu:', hx1.shape)
        hx = self.pool1(hx1)
        # print('pool1:', hx.shape)

        hx2 = self.relu2(self.bn2(self.conv2(hx)))
        # print('conv2:', hx2.shape)
        hx = self.pool2(hx2)
        # print('pool2:', hx.shape)

        hx3 = self.relu3(self.bn3(self.conv3(hx)))
        # print('conv3', hx3.shape)
        hx = self.pool3(hx3)
        # print('pool3:', hx.shape)

        hx4 = self.relu4(self.bn4(self.conv4(hx)))
        # print('conv4:', hx4.shape)
        hx = self.pool4(hx4)
        # print('pool4:', hx.shape)

        hx5 = self.relu5(self.bn5(self.conv5(hx)))
        # print('conv5:', hx5.shape)
        hx = self.upscore2(hx5)
        # print('upscore2:', hx.shape)

        d4 = self.relu_d4(self.bn_d4(self.conv_d4(torch.cat((hx,hx4),1))))
        # print('conv_d4:', d4.shape)
        hx = self.upscore2(d4)
        # print('upscore:', hx.shape)

        d3 = self.relu_d3(self.bn_d3(self.conv_d3(torch.cat((hx,hx3),1))))
        # print('conv_d3:', d3.shape)
        hx = self.upscore2(d3)
        # print('upscore:', hx.shape)
        d2 = self.relu_d2(self.bn_d2(self.conv_d2(torch.cat((hx,hx2),1))))
        # print('conv_d2:', d2.shape)
        hx = self.upscore2(d2)
        # print('upscore:', hx.shape)

        d1 = self.relu_d1(self.bn_d1(self.conv_d1(torch.cat((hx,hx1),1))))
        # print('conv_d1:', d1.shape)
        #这个卷积报错了，试试用d2 d2可能放进 cov_d0(d2)

        residual = self.conv_d0(d1)
        # print('conv_d0:', residual.shape)
        x = x+residual
        # add = self.conv_d10(ori)
        # print(x.shape)
        # exit()
        return x

class TransGANets(nn.Module):
    def __init__(self,n_channels, n_classes):
        super(TransGANets,self).__init__()

        # ## -------------Bilinear Upsampling--------------

        self.upscore5 = nn.Upsample(scale_factor=16,mode='bilinear',align_corners=False)
        self.upscore4 = nn.Upsample(scale_factor=8,mode='bilinear',align_corners=False)
        self.upscore3 = nn.Upsample(scale_factor=4,mode='bilinear',align_corners=False)
        self.upscore2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)

        self.diffnet = DiffNet(n_classes,1) #n_classes
        self.backbone = {'b4': mit_b4}['b4'](True)

        self.conv_seg = nn.Conv2d(256, 1, kernel_size=1)
        self.conv_seg_cat = nn.Conv2d(768, 1, kernel_size=1)
        self.unet = UNet(3, 1)
        self.fusion1 = Fusion_dsc().cuda()
        self.fusion2_1 = CascadeFusion(128).cuda()
        self.fusion2_2 = CascadeFusion(64).cuda()
        self.multiattention = Multi_Attention()

    def forward(self, x):

        hx = x  # 6,3,321,321
        # print(hx.shape)
        hx = t_resize(hx)

        sobel_x = cv2.Sobel(np.asarray(hx[0].permute(1, 2, 0).cpu()), cv2.CV_64F, 1, 0)
        sobel_x = cv2.convertScaleAbs(sobel_x)
        # y方向
        sobel_y = cv2.Sobel(np.asarray(hx[0].permute(1, 2, 0).cpu()), cv2.CV_64F, 0, 1)
        sobel_y = cv2.convertScaleAbs(sobel_y)
        # x,y方向
        sobel_xy = cv2.Sobel(np.asarray(hx[0].permute(1, 2, 0).cpu()), cv2.CV_64F, 1, 1)
        sobel_xy = cv2.convertScaleAbs(sobel_xy)
        # x,y方向叠加
        sobel_x_y = cv2.addWeighted(sobel_x, 0.5, sobel_y, 0.5, 0)
        sobel_x_y_batch = np.expand_dims(sobel_x_y, 0)

        if x.shape[0] > 1:
            for j in range(x.shape[0]-1):
                sobel_x = cv2.Sobel(np.asarray(hx[j].permute(1, 2, 0).cpu()), cv2.CV_64F, 1, 0)
                sobel_x = cv2.convertScaleAbs(sobel_x)
                # y方向
                sobel_y = cv2.Sobel(np.asarray(hx[j].permute(1, 2, 0).cpu()), cv2.CV_64F, 0, 1)
                sobel_y = cv2.convertScaleAbs(sobel_y)
                # x,y方向
                sobel_xy = cv2.Sobel(np.asarray(hx[j].permute(1, 2, 0).cpu()), cv2.CV_64F, 1, 1)
                sobel_xy = cv2.convertScaleAbs(sobel_xy)
                # x,y方向叠加
                sobel_x_y = cv2.addWeighted(sobel_x, 0.5, sobel_y, 0.5, 0)
                sobel_x_y = np.expand_dims(sobel_x_y, 0)
                sobel_x_y_batch = np.concatenate([sobel_x_y_batch, sobel_x_y], axis=0)
        else:
            # for j in range(1):
            sobel_x_y_batch = sobel_x_y_batch

        ## -------------Stage I Encoder-------------
        out = []

        sobel_x_y_batch = sobel_x_y_batch.transpose((0, 3, 1, 2))
        sobel_x_y_batch = torch.from_numpy(sobel_x_y_batch)
        sobel_x_y_batch = sobel_x_y_batch.to(device).float()
        x_s1 = self.unet(sobel_x_y_batch)['out']  # torch.Size([1, 2, 196, 196])
        x_s1_1 = stage1_resize(x_s1)
        # x_s1_2 = stage2_resize(x_s1)

        ## -------------Stage II Encoder-------------
        x = self.backbone.forward(hx)
        #torch.Size([2, 64, 96, 96]) ([2, 128, 48, 48]) ([2, 320, 24, 24]) ([2, 512, 12, 12])

        x_fuse = self.fusion1(x[3].cpu(), x_s1_1.cpu(), x[2].cpu()).cuda()
        # print(x_fuse.shape) #torch.Size([2, 256, 24, 24])
        x_cas1 = self.fusion2_1(x_fuse.cuda(), x[1].cuda())
        # print(x_cas1.shape) torch.Size([2, 256, 48, 48])
        x_cas2 = self.fusion2_2(x_cas1.cuda(), x[0].cuda())
        # print(x_cas2.shape) torch.Size([2, 256, 96, 96])

        x_fuse_loss = self.conv_seg(self.upscore5(x_fuse))
        x_cas1_loss = self.conv_seg(self.upscore4(x_cas1))
        x_cas2_loss = self.conv_seg(self.upscore3(x_cas2))

        x_cat = []
        x_cat.append(self.upscore3(x_fuse))
        x_cat.append(self.upscore2(x_cas1))
        x_cat.append(x_cas2)
        x_cat_loss = self.conv_seg_cat(self.upscore3(self.multiattention(x_cat)))

        x = self.diffnet(x_cat_loss)

        x_loss = {"x_fuse_loss": torch.sigmoid(x_fuse_loss), "x_cas1_loss": torch.sigmoid(x_cas1_loss), "x_cas2_loss": torch.sigmoid(x_cas2_loss),
                  "x_cat_loss": torch.sigmoid(x_cat_loss), "output": torch.sigmoid(x)}

        return x_loss

if __name__=="__main__":
    a = torch.randn(1,3,321,321)
    print(a)
    net = BoundaryNets(3, 1)
    module = net(a)
    print(module[0])
