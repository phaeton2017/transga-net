
import argparse
import gc
import logging
import os
import timeit

import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
import torch.backends.cudnn as cudnn
from PIL import Image
from matplotlib import pyplot as plt
from sklearn import metrics
# from tensorboard.summary import Writer
from tensorboardX import SummaryWriter
from torch.utils import data
from torch.autograd import Variable
import torchvision.transforms as transform
from torchvision.transforms import transforms, Resize
from TransGA import TransGANets
from model.utils.visualization import subplotimg

from loss import iou_loss
from data_loader_SPARCS_ORI import CloudDataset, ToTensorNorm
# from data_loader_SPARCS_senti import CloudDataset, ToTensorNorm
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
torch.cuda.device_count()
start = timeit.default_timer()
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:200'
CHECKPOINT_DIR = './checkpoints/gf2_csdnetv1/'

#checkpoints_advent_feature/voc_advent_feature_landsat_layer3


# -------  load the train dataset --------
# train_txt = './data/cloud/train/train.txt'  # "/media/xk/新加卷1/wwxdata/cloud_source/train.txt"
# train_txt = "/media/xk/新加卷/wwxdata/cloud_source/train.txt"
train_txt = '/media/xk/新加卷1/wwxdata/clouddata/GF-2/cloud_multi/train_multi.txt'
with open(train_txt, 'r', encoding='utf-8') as f:
    train_list = f.readlines()
val_txt = "/media/xk/新加卷1/wwxdata/clouddata/GF-2/cloud_multi/test_multi.txt"
# val_txt = '/media/xk/新加卷1/sentinel_99/test.txt'
with open(val_txt, 'r', encoding='utf-8') as f:
    val_list = f.readlines()

THRESHOLD_VALUE= 0.55
GPU_NUMBER=0
os.environ['CUDA_VISIBLE_DEVICES']='0'

IMG_MEAN = np.array((85.27698793,85.21876762,85.17891434), dtype=np.float32) # zy3
#IMG_MEAN2 = np.array((69.44698793,51.68876762,49.67891434), dtype=np.float32) # landsat

NUM_CLASSES = 1 # 21 for PASCAL-VOC / 60 for PASCAL-Context / 19 Cityscapes
DATASET = 'pascal_voc' #pascal_voc or pascal_context 

SPLIT_ID = './splits/voc/split_0.pkl'

MODEL = 'DeepLab'
BATCH_SIZE = 5
NUM_STEPS = 80000
SAVE_PRED_EVERY = 500

INPUT_SIZE = '321,321'
IGNORE_LABEL = 255 # 255 for PASCAL-VOC / -1 for PASCAL-Context / 250 for Cityscapes

RESTORE_FROM = './models/resnet50-19c8e357.pth'

LEARNING_RATE = 1e-4
LEARNING_RATE_D = 1e-4

POWER = 0.9
WEIGHT_DECAY = 0.0005
MOMENTUM = 0.9
NUM_WORKERS = 4
RANDOM_SEED = 1234

LAMBDA_ST = 1.0
LAMBDA_FM = 0.5
LAMBDA_CE = 0.5
LAMBDA_ADAPT = 0.001
LAMBDA_ENTROPY = 0.01


#LAMBDA_ADAPT = 1.0

THRESHOLD_ST = 0.6 # 0.6 for PASCAL-VOC/Context / 0.7 for Cityscapes

LABELED_RATIO = None  #0.02 # 1/8 labeled data by default

Writer =SummaryWriter('../CDnetV2-pytorch-master-main/checkpoints/gf2_csdnetv1/writer')

is_resume = False
restore = '/media/xk/新加卷/code/CDnetV2-pytorch-master-main/CDnetV2-pytorch-master-main/checkpoints/landsat_cdnetv2/VOC_19000.pth'

def get_arguments():
    """Parse all the arguments provided from the CLI.

    Returns:
      A list of parsed arguments.
    """
    parser = argparse.ArgumentParser(description="DeepLab-ResNet Network")
    parser.add_argument("--gpu", type=int, default=GPU_NUMBER,
                        help="choose gpu device.")	
    # parser.add_argument("--data-list", type=str, default=DATA_LIST_PATH,
    #                     help="Path to the LANDSAT-8 file listing the images in the dataset.")
    # parser.add_argument("--data-list2", type=str, default=DATA_LIST_PATH2,
    #                     help="Path to the gf1 file listing the images in the dataset.")
    # parser.add_argument("--data-list3", type=str, default=DATA_LIST_PATH3,
    #                     help="Path to the gf1 file listing the images in the dataset.")
	#
    parser.add_argument("--checkpoint-dir", type=str, default=CHECKPOINT_DIR,
                        help="Where to save checkpoints of the model.")
				
    parser.add_argument("--model", type=str, default=MODEL,
                        help="available options : DeepLab/DRN")
    parser.add_argument("--dataset", type=str, default=DATASET,
                        help="dataset to be used")
    # parser.add_argument("--layer_name", type=str, default=LAYER_NAME,
                        # help="layer_name to be used")
						
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE,
                        help="Number of images sent to the network in one step.")
    parser.add_argument("--num-workers", type=int, default=NUM_WORKERS,
                        help="number of workers for multithread dataloading.")
    # parser.add_argument("--gf-data-dir", type=str, default=GF_DATA_DIR,
    #                     help="Path to the directory containing the GF1 dataset.")
    # parser.add_argument("--land-data-dir", type=str, default=LAND_DATA_DIR,
    #                     help="Path to the directory containing the LANDSAT-8 dataset.")
						
    parser.add_argument("--labeled-ratio", type=float, default=LABELED_RATIO,
                        help="ratio of the labeled data to full dataset")
    parser.add_argument("--split-id", type=str, default=SPLIT_ID,
                        help="split order id")
    parser.add_argument("--input-size", type=str, default=INPUT_SIZE,
                        help="Comma-separated string with height and width of images.")
    parser.add_argument("--learning-rate", type=float, default=LEARNING_RATE,
                        help="Base learning rate for training with polynomial decay.")
    parser.add_argument("--learning-rate-D", type=float, default=LEARNING_RATE_D,
                        help="Base learning rate for discriminator.")
    parser.add_argument("--lambda-fm", type=float, default=LAMBDA_FM,
                        help="lambda_fm for feature-matching loss.")
    parser.add_argument("--lambda-st", type=float, default=LAMBDA_ST,
                        help="lambda_st for self-training.")
    parser.add_argument("--lambda-adapt", type=float, default=LAMBDA_ADAPT,
                        help="lambda_adapt for self-training.")
    parser.add_argument("--lambda-ce", type=float, default=LAMBDA_CE,
                        help="lambda_adapt for self-training.")						
    parser.add_argument("--lambda-entropy", type=float, default=LAMBDA_ENTROPY,
                        help="lambda_entropy for entropy loss.")		  

                        
    parser.add_argument("--threshold-st", type=float, default=THRESHOLD_ST,
                        help="threshold_st for the self-training threshold.")
    parser.add_argument("--threshold-value", type=float, default=THRESHOLD_VALUE,
                        help="threshold_value for the self-training threshold.")						
						
    parser.add_argument("--momentum", type=float, default=MOMENTUM,
                        help="Momentum component of the optimiser.")
    parser.add_argument("--ignore-label", type=float, default=IGNORE_LABEL,
                        help="label value to ignored for loss calculation")
    parser.add_argument("--num-classes", type=int, default=NUM_CLASSES,
                        help="Number of classes to predict (including background).")
    parser.add_argument("--num-steps", type=int, default=NUM_STEPS,
                        help="Number of iterations.")
    parser.add_argument("--power", type=float, default=POWER,
                        help="Decay parameter to compute the learning rate.")
    parser.add_argument("--random-mirror", action="store_true",
                        help="Whether to randomly mirror the inputs during the training.")
    parser.add_argument("--random-scale", action="store_true",
                        help="Whether to randomly scale the inputs during the training.")
    parser.add_argument("--random-seed", type=int, default=RANDOM_SEED,
                        help="Random seed to have reproducible results.")
    parser.add_argument("--restore-from", type=str, default=RESTORE_FROM,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D", type=str, default=None,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D1", type=str, default=None,
                        help="Where restore model parameters from.")	
    parser.add_argument("--restore-from-D2", type=str, default=None,
                        help="Where restore model parameters from.")	
						
    parser.add_argument("--restore-from-D31", type=str, default=None,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D32", type=str, default=None,
                        help="Where restore model parameters from.")	
    parser.add_argument("--restore-from-D33", type=str, default=None,
                        help="Where restore model parameters from.")		
    parser.add_argument("--restore-from-D34", type=str, default=None,
                        help="Where restore model parameters from.")		

    parser.add_argument("--restore-from-D41", type=str, default=None,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D42", type=str, default=None,
                        help="Where restore model parameters from.")	
    parser.add_argument("--restore-from-D43", type=str, default=None,
                        help="Where restore model parameters from.")		
    parser.add_argument("--restore-from-D44", type=str, default=None,
                        help="Where restore model parameters from.")	

    parser.add_argument("--restore-from-D_D31", type=str, default=None,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D_D32", type=str, default=None,
                        help="Where restore model parameters from.")	
    parser.add_argument("--restore-from-D_D33", type=str, default=None,
                        help="Where restore model parameters from.")		
    parser.add_argument("--restore-from-D_D34", type=str, default=None,
                        help="Where restore model parameters from.")		

    parser.add_argument("--restore-from-D_D41", type=str, default=None,
                        help="Where restore model parameters from.")
    parser.add_argument("--restore-from-D_D42", type=str, default=None,
                        help="Where restore model parameters from.")	
    parser.add_argument("--restore-from-D_D43", type=str, default=None,
                        help="Where restore model parameters from.")		
    parser.add_argument("--restore-from-D_D44", type=str, default=None,
                        help="Where restore model parameters from.")	

						
    parser.add_argument("--save-pred-every", type=int, default=SAVE_PRED_EVERY,
                        help="Save summaries and checkpoint every often.")

    parser.add_argument("--weight-decay", type=float, default=WEIGHT_DECAY,
                        help="Regularisation parameter for L2-loss.")

    return parser.parse_args()

args = get_arguments()

def save_output(image_name, pred, d_dir,OA):
    predict = pred
    predict = predict.squeeze()
    predict_np = (predict * 255).astype(np.uint8)
    # print("SAVE", predict_np)
    # print(predict_np)

    # color_file = Image.fromarray(colorize(predict_np).transpose(1, 2, 0), 'RGB')
    im = Image.fromarray(predict_np).convert('RGB')
    # im.show()
    # img = Image.fromarray(colorize(color_file).transpose(1, 2, 0), 'RGB')
    im.save(d_dir + '/' + image_name[:-6] + "_%3f" % (OA) +'.png')

def get_log(file_name):
    logger = logging.getLogger('val')  # 设定logger的名字
    logger.setLevel(logging.INFO)  # 设定logger得等级

    ch = logging.StreamHandler()  # 输出流的hander，用与设定logger的各种信息
    ch.setLevel(logging.INFO)  # 设定输出hander的level

    fh = logging.FileHandler(file_name, mode='a')  # 文件流的hander，输出得文件名称，以及mode设置为覆盖模式
    fh.setLevel(logging.INFO)  # 设定文件hander得lever

    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)  # 两个hander设置个是，输出得信息包括，时间，信息得等级，以及message
    fh.setFormatter(formatter)
    logger.addHandler(fh)  # 将两个hander添加到我们声明的logger中去
    logger.addHandler(ch)
    return logger

logger = get_log('../CDnetV2-pytorch-master-main/checkpoints/gf2_csdnetv1/log.txt')

bce_loss = nn.BCELoss(size_average=True)
iou_loss = iou_loss.IOU(size_average=True)


def dl_loss(pred, target):
    bce_out = bce_loss(pred, target)
    iou_out = iou_loss(pred, target)

    loss = bce_out + iou_out

    return loss


# def muti_loss_fusion(out, d1, d2, d3, d4, labels_v):
# def muti_loss_fusion(out, d1, labels_v):
def muti_loss_fusion(out, labels_v):
    loss0 = dl_loss(out, labels_v)
    # loss1 = dl_loss(d1, labels_v)
    # loss2 = dl_loss(d2, labels_v)
    # loss3 = dl_loss(d3, labels_v)
    # loss4 = dl_loss(d4, labels_v)
    # loss5 = dl_loss(d5, labels_v)
    # loss6 = dl_loss(d6, labels_v)
    # loss7 = dl_loss(d7, labels_v)

    loss = loss0 #+ loss1 #+ loss2 + loss3 + loss4 #+ loss5 + loss6 + loss7

    return loss0 #loss

def lr_poly(base_lr, iter, max_iter, power):
    return base_lr*((1-float(iter)/max_iter)**(power))

def adjust_learning_rate(optimizer, i_iter):
    lr = lr_poly(args.learning_rate, i_iter, args.num_steps, args.power)
    optimizer.param_groups[0]['lr'] = lr
    if len(optimizer.param_groups) > 1 :
        optimizer.param_groups[1]['lr'] = lr * 10

def adjust_learning_rate_D(optimizer, i_iter):
    lr = lr_poly(args.learning_rate_D, i_iter, args.num_steps, args.power)
    optimizer.param_groups[0]['lr'] = lr
    if len(optimizer.param_groups) > 1 :
        optimizer.param_groups[1]['lr'] = lr * 10

def one_hot(label):
    label = label.numpy()  # N,H,W
    one_hot = np.zeros((label.shape[0], args.num_classes, label.shape[1], label.shape[2]), dtype=label.dtype)  # N,C,H,W
    for i in range(args.num_classes):
        one_hot[:,i,...] = (label==i)
    #handle ignore labels
    return torch.FloatTensor(one_hot)

def compute_argmax_map(output):
    output = output.detach().cpu().numpy() #  c,H,W
    output = output.transpose((1,2,0))  # H,W,c
    output = np.asarray(np.argmax(output, axis=2), dtype=np.int) # H,W; obtain the index thatrepresented the max value through the axis==2 (i.e., channel)
    output = torch.from_numpy(output).float()  # numpy-->torch-->torch float 
    return output
     
def find_good_maps(D_outs, pred_all):
    count = 0
    for i in range(D_outs.size(0)):  # N,C
        if D_outs[i] > args.threshold_st:
            count +=1

    if count > 0:
        #print ('Above ST-Threshold : ', count, '/', args.batch_size)
        pred_sel = torch.Tensor(count, pred_all.size(1), pred_all.size(2), pred_all.size(3)) # n,c,h,w
        label_sel = torch.Tensor(count, pred_sel.size(2), pred_sel.size(3)) # n,h,w
        num_sel = 0 
        for j in range(D_outs.size(0)):
            if D_outs[j] > args.threshold_st:
                pred_sel[num_sel] = pred_all[j]  # get the pred_all[*] map large than threshold value 
                label_sel[num_sel] = compute_argmax_map(pred_all[j]) # score map --> label map with channel==1

                num_sel +=1
        #return  pred_sel.cuda(args.gpu), label_sel.cuda(args.gpu), count  
        return  pred_sel.cuda(), label_sel.cuda(), count  		
    else:
        return 0, 0, count 

		
def compute_ignore_mask(pred0, max_pred):
    pred0 = pred0.detach() # c,H,W    
    pred = torch.chunk(torch.squeeze(pred0,0),2,dim=0)
    pred_1 = torch.squeeze(pred[0],0)	# 1,h,w-->h,w
    pred_1 = pred_1.cpu().numpy() 
    pred_1[pred_1 > args.threshold_value] = 0
    pred_1[pred_1 < 1-args.threshold_value] = 0
    pred_1[pred_1 > 0] = 255    #h,w
    max_pred = max_pred.cpu().numpy() 	
    mask = 	max_pred + pred_1
    mask[mask > 2] = 255  	
    mask =torch.from_numpy(mask) #h,w
    
    return mask	


def find_good_maps_new(D_outs, pred_all, pred_all_2):
    count = 0
    for i in range(D_outs.size(0)):  # N,C
        if D_outs[i] > args.threshold_st:
            count +=1

    if count > 0:
        #print ('Above ST-Threshold : ', count, '/', args.batch_size)
        pred_sel = torch.Tensor(count, pred_all.size(1), pred_all.size(2), pred_all.size(3)) # n,c,h,w
        label_sel = torch.Tensor(count, pred_sel.size(2), pred_sel.size(3)) # n,h,w
        num_sel = 0 
        for j in range(D_outs.size(0)):
            if D_outs[j] > args.threshold_st:
                pred_sel[num_sel] = pred_all[j]  # c,h,w; get the pred_all[*] map large than threshold value 
                #label_sel[num_sel] = compute_argmax_map(pred_all[j]) # H,W; score map --> label map with channel==1
                label_sel[num_sel] = compute_ignore_mask( pred_all_2[j], compute_argmax_map(pred_all[j]) )
                num_sel +=1
        #return  pred_sel.cuda(args.gpu), label_sel.cuda(args.gpu), count  
        return  pred_sel.cuda(), label_sel.cuda(), count  		
    else:
        return 0, 0, count


criterion = nn.BCELoss()

def main():
    print (args)

    h, w = map(int, args.input_size.split(','))
    input_size = (h, w)

    cudnn.enabled = True
    #gpu = args.gpu

    # create network
    model = CSDNet(3, 2)
    # model = CDnetV2(num_classes=args.num_classes)
    # model = BoundaryNets(3,1)
    # load pretrained parameters
    saved_state_dict = torch.load(args.restore_from)
    new_params = model.state_dict().copy()
    for name, param in new_params.items():
        if name in saved_state_dict and param.size() == saved_state_dict[name].size():
            new_params[name].copy_(saved_state_dict[name])
    model.load_state_dict(new_params)
	
    #model.load_state_dict(torch.load('./checkpoints/checkpoints_zy3_CDnetV1/VOC_2w.pth'))	
	
    model.train()
    #model.cuda(args.gpu)
    model.cuda()
    cudnn.benchmark = True

    optimizer = optim.SGD(model.parameters(),
                          lr=args.learning_rate, momentum=args.momentum,
                          weight_decay=args.weight_decay)  # if weight_decay=0.0，there is no regularization term
    start_iter = 0

    if is_resume:
        saved_state_dict1 = torch.load(restore)
        model.load_state_dict(saved_state_dict1)

        print('start iter', restore[-9:-4])
        start_iter = int(restore[-9:-4]) + 1

    if not os.path.exists(args.checkpoint_dir):
        os.makedirs(args.checkpoint_dir)
		
    # load data and do preprocessing,such as rescale,flip
    if args.dataset == 'pascal_voc':    
        train_dataset = CloudDataset(
            file_name_list=train_list,
            transform=transforms.Compose([
                ToTensorNorm(),
                # RandomHorizontallyFlip(),
            ]), test_mode=0)
        val_dataset = CloudDataset(
            file_name_list=val_list,
            transform=transforms.Compose([
                ToTensorNorm(),
                # RandomHorizontallyFlip(),
            ]), test_mode=1)

    elif args.dataset == 'pascal_context':
        input_transform = transform.Compose([transform.ToTensor(),
            transform.Normalize([.406, .456, .485], [.229, .224, .225])])
        # data_kwargs = {'transform': input_transform, 'base_size': 505, 'crop_size': 321}
        # #train_dataset = get_segmentation_dataset('pcontext', split='train', mode='train', **data_kwargs)
        # data_loader = get_loader('pascal_context')
        # data_path = get_data_path('pascal_context') 
        # train_dataset = data_loader(data_path, split='train', mode='train', **data_kwargs)
        # #train_gt_dataset = data_loader(data_path, split='train', mode='train', **data_kwargs)
        
    # elif args.dataset == 'cityscapes':
        # data_loader = get_loader('cityscapes')
        # data_path = get_data_path('cityscapes')
        # data_aug = Compose([RandomCrop_city((256, 512)), RandomHorizontallyFlip()])
        # train_dataset = data_loader( data_path, is_transform=True, augmentations=data_aug) 
        # #train_gt_dataset = data_loader( data_path, is_transform=True, augmentations=data_aug) 

    train_dataset_size = len(train_dataset)
    print ('train dataset size: ', train_dataset_size)
    val_dataset_size = len(val_dataset)
    print ('val dataset size: ', val_dataset_size)

    if args.labeled_ratio is None:
        trainloader = data.DataLoader(train_dataset,
                        batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=True)

        valloader = data.DataLoader(val_dataset,
                        batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=True)
    else:
        partial_size = int(args.labeled_ratio * train_dataset_size)

    trainloader_iter = iter(trainloader)
    valloader_iter = iter(valloader)

	
    # trainloader_gt_iter = iter(trainloader_gt)

    # optimizer for segmentation network
    optimizer.zero_grad()


	
    # interp = nn.Upsample(size=(input_size[0], input_size[1]), mode='bilinear', align_corners=True)
    interp = nn.Upsample(size=(384, 384), mode='bilinear', align_corners=True)

    acc = 0
    precision = 0
    recall = 0
    epoch = -1

    print('----------------Training----------------------')
    for i_iter in  range(start_iter, args.num_steps+1):
    #for i_iter in  range(60001, args.num_steps+1):

        if i_iter % 2110 == 0:
            epoch = epoch + 1
        loss_ce_value = 0
        loss_pred_value = 0
        loss_all_value = 0
        loss_all_value = 0

		
        optimizer.zero_grad()
        adjust_learning_rate(optimizer, i_iter)
        
        try:
            batch = next(trainloader_iter)
        except:
            trainloader_iter = iter(trainloader)
            batch = next(trainloader_iter)

        # t_resize = Resize([384, 384])
        images, labels = batch['image'], batch['mask']
        images = Variable(images).cuda()
        labels = Variable(labels).cuda()

        pred = model(interp(images))
        # pred, pred_aux = model(interp(images))

        # # pred, d1, d2, d3, d4, d5, d6, d7 = model(interp(images))
        # dir = model(interp(images))
        # pred, x_fuse_loss, x_cas1_loss, x_cas2_loss, x_cat_loss = dir["output"], dir["x_fuse_loss"], dir["x_cas1_loss"], \
        #                                                       dir["x_cas2_loss"], dir["x_cat_loss"]
    #
        pred = torch.sigmoid(interp(pred))
        labels = interp(labels)
        # pred_aux = interp(pred_aux)
        # print(pred, labels)
        loss_all = muti_loss_fusion(pred, labels)

        # loss_pred, loss_all = muti_loss_fusion(pred, x_fuse_loss, x_cas1_loss, x_cas2_loss, x_cat_loss, labels)
        # loss_pred, loss_all = muti_loss_fusion(pred, pred_aux, labels)
        # loss_pred, loss_all = muti_loss_fusion(pred, d1, d2, d3, d4, d5, d6, d7, labels)

        loss_all.requires_grad_(True)
        loss_all.backward()
        loss_all_value += loss_all.item()
        # loss_pred_value += loss_pred.item()

        optimizer.step()

        # print(pred_label, true_label)
        for a in range(len(pred_label)):
            if pred_label[a] > 0.5:
                pred_label[a] = 1
            else:
                pred_label[a] = 0

        targetpred = pred_label.reshape(args.batch_size, 384, 384)
        # print(targetpred)
        recall_score = metrics.recall_score(true_label, pred_label, average='macro')  # 召回率
        pre_score = metrics.precision_score(true_label, pred_label, average='macro')  # 准确率
        ACC = metrics.accuracy_score(true_label, pred_label)  # 准确度ACC
        for j in range(args.batch_size):
            out_dir = os.path.join('../CDnetV2-pytorch-master-main/checkpoints/gf2_csdnetv1/out/writer/' + f'{(epoch):04d}')
            out_dir_output = os.path.join(
                '../CDnetV2-pytorch-master-main/checkpoints/gf2_csdnetv1/out/output/' + f'{(epoch):04d}')

            os.makedirs(out_dir, exist_ok=True)
            os.makedirs(out_dir_output, exist_ok=True)
            # print(batch['name'][j])
            image_t = Image.open('/media/xk/新加卷1/wwxdata/clouddata/GF-2/cloud_multi/rgb/' + batch['name'][j] )#+'.png')
            imagename = batch['name'][j]
            # print(os.path.join(out_dir, imagename))
            rows, cols = 1, 3
            fig, axs = plt.subplots(
                rows,
                cols,
                figsize=(4 * cols, 4 * rows),
            )
            subplotimg(axs[0], np.asarray(image_t), 'Image')
            subplotimg(axs[1],
                       targetlabel[j],  # gt_semantic_seg[j],
                       'label',
                       cmap='cityscapes')
            subplotimg(axs[2],
                       targetpred[j],  # gt_semantic_seg[j],
                       'Pred',
                       cmap='cityscapes')
            for ax in axs.flat:
                ax.axis('off')
            plt.savefig(
                os.path.join(out_dir,
                             imagename[:-4] + str(ACC)) + '.jpg')
            plt.close()
            save_output(imagename, targetpred[j], out_dir_output,ACC)
        # Writer.add_scalar("l_ce", loss_pred , i_iter)
        Writer.add_scalar("l_all", loss_all, i_iter)
        Writer.add_scalar("acc", ACC, i_iter)
        Writer.add_scalar("pre_score", pre_score, i_iter)
        Writer.add_scalar("recall", recall_score, i_iter)

        acc = acc + ACC
        precision = pre_score + precision
        recall = recall_score + recall
        if i_iter % 20 == 0:
            # print('iter={0:5d},l_ce={1:.3f}, l_pred={2:.3f}, l_aux1={3:.3f}, l_aux2={4:.3f}, l_aux3={5:.3f},'.format(i_iter, loss_ce_value, loss_pred_value, loss_aux1_value, loss_aux2_value, loss_aux3_value, loss_aux1_value ))
            train_str = ('iter={0:5d}, l_all={1:.3f}, ACC={2:.3f}, Recall_score={3:.3f}, Precision={4:.3f}'.format(
                    i_iter, loss_all_value, ACC, recall_score, pre_score))
            logger.info(train_str)

        # if i_iter %20 ==0:
        #         #print('iter={0:5d},l_ce={1:.3f}, l_pred={2:.3f}, l_aux1={3:.3f}, l_aux2={4:.3f}, l_aux3={5:.3f},'.format(i_iter, loss_ce_value, loss_pred_value, loss_aux1_value, loss_aux2_value, loss_aux3_value, loss_aux1_value ))
        #         train_str = (
        #             'iter={0:5d}, l_ce={1:.3f}, l_all={2:.3f}, ACC={3:.3f}, Recall_score={4:.3f}, Precision={5:.3f}, '.format(
        #                 i_iter, loss_pred, loss_all_value, ACC, recall_score, pre_score))
        #         logger.info(train_str)
                # print('iter={0:5d}, l_ce={1:.3f}, l_all={2:.3f}'.format(i_iter, loss_pred, loss_all_value))
        if i_iter >= args.num_steps-1:
            print ('save model ...')
            torch.save(model.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'.pth'))
            #torch.save(model_D1.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(args.num_steps)+'_D1.pth'))
            break

        ACC_v = 0
        pre_score_v = 0
        recall_score_v = 0

        if i_iter % args.save_pred_every == 0 and i_iter!=0:
            print('Validation ...')
            val_train_str = (
                'iter={0:5d}, l_all={1:.3f}, ACC={2:.3f}, Recall_score={3:.3f}, Precision={4:.3f}, '.format(
                    i_iter, loss_all_value, acc / i_iter, recall_score / i_iter, pre_score / i_iter))
            # val_train_str = (
            #     'iter={0:5d}, l_ce={1:.3f}, l_all={2:.3f}, ACC={3:.3f}, Recall_score={4:.3f}, Precision={5:.3f}, '.format(
            #         i_iter, loss_pred, loss_all_value, acc / i_iter, recall_score / i_iter, pre_score / i_iter))
            logger.info(val_train_str)
            print ('saving checkpoint  ...')
            torch.save(model.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'.pth'))
            #torch.save(model_D1.state_dict(),os.path.join(args.checkpoint_dir, 'VOC_'+str(i_iter)+'_D1.pth'))

            try:
                batch = next(valloader_iter)
            except:
                valloader_iter = iter(valloader)
                batch = next(valloader_iter)

            # t_resize = Resize([384, 384])
            images, labels = batch['image'], batch['mask']
            images = Variable(images).cuda()
            labels = Variable(labels).cuda()

            with torch.no_grad():
                # dir = model(images)
                # pred, pred_aux = model(interp(images))
                pred = model(interp(images))
                # pred, x_fuse_loss, x_cas1_loss, x_cas2_loss, x_cat_loss = dir["output"], dir["x_fuse_loss"], dir[
                #     "x_cas1_loss"], \
                #                                                           dir["x_cas2_loss"], dir["x_cat_loss"]

                # pred, d1, d2, d3, d4, d5, d6, d7 = model(interp(images))
                #
            pred = torch.sigmoid(interp(pred))
            # pred = interp(pred)
            labels = interp(labels)
            # pred_aux = interp(pred_aux)

            # loss_pred_v, loss_all_v = muti_loss_fusion(pred, x_fuse_loss, x_cas1_loss, x_cas2_loss, x_cat_loss, labels)
            loss_pred_v = muti_loss_fusion(pred, labels)
            # loss_pred_v, loss_all_v = muti_loss_fusion(pred, d1, d2, d3, d4, d5, d6, d7, labels)
            pred = interp(pred)
            # pred_aux = interp(pred_aux)
            # loss_pred_v, loss_all_v = muti_loss_fusion(pred, pred_aux, pred_aux, pred_aux, pred_aux, labels)

            pred_label = pred.data.cpu().numpy()
            true_label = labels.data.cpu().numpy()
            targetlabel = true_label
            pred_label = pred_label.flatten()
            true_label = true_label.flatten()
            true_label = true_label.astype("int")
            # print(pred_label, true_label)
            for a in range(len(pred_label)):
                if pred_label[a] > 0.5:
                    pred_label[a] = 1
                else:
                    pred_label[a] = 0

            targetpred = pred_label.reshape(args.batch_size, 384, 384)
            R = metrics.recall_score(true_label, pred_label, average='macro')  # 召回率
            P = metrics.precision_score(true_label, pred_label, average='macro')  # 准确率
            A = metrics.accuracy_score(true_label, pred_label)  # 准确度ACC
            ACC_v = ACC_v + A
            pre_score_v = P + pre_score_v
            recall_score_v = recall_score_v + R

            Writer.add_scalar("l_ce_v", loss_pred_v, i_iter)
            # Writer.add_scalar("l_all_v", loss_all_v, i_iter)
            Writer.add_scalar("acc_v", ACC_v, i_iter)
            Writer.add_scalar("pre_score_v", pre_score_v, i_iter)
            Writer.add_scalar("recall_v", recall_score_v, i_iter)

        if i_iter % args.save_pred_every == 0 and i_iter != 0:
        #     print(
        # 'i_iter={0:5d}, ACC_v={1:.3f}, pre_score_v={2:.3f}, recall_score_v={3:.3f}, '.format(
        #     epoch, ACC_v, pre_score_v, recall_score_v))
            val_str = (
                'i_iter={0:5d}, ACC_v={1:.3f}, pre_score_v={2:.3f}, recall_score_v={3:.3f}, '.format(
                    i_iter, ACC_v, pre_score_v, recall_score_v))
            logger.info(val_str)
        gc.collect()
        torch.cuda.empty_cache()

    end = timeit.default_timer()
    print (end-start,'seconds')


if __name__ == '__main__':
    main()
