# data loader
from __future__ import print_function, division
import os
import torch
from PIL import Image
# from skimage import io
import numpy as np
from torch.utils.data import Dataset, DataLoader
from torchvision.transforms import Resize


#from osgeo import gdal

#==========================dataset load==========================
class ToTensorNorm(object):
    """Convert ndarrays in sample to Tensors."""
    def __init__(self):
        pass
    def __call__(self, sample):
        
        image, label = sample['image'], sample['mask']
        
        if (np.max(label) < 1e-6):
            label = label
        else:
            label = label / np.max(label)
        
        if np.max(image) != 0:
            image = image / np.max(image)
        else:
            image = image

        return {'image': torch.from_numpy(image),
                'mask': torch.from_numpy(label)}

class CloudDataset(Dataset):
    def __init__(self, file_name_list, transform=None, test_mode=1):
        self.file_name_list = file_name_list
        # self.label_name_list = lbl_nam
        # e_list
        self.transform = transform
        # self.root = './data'#'/media/xk/新加卷/code/DAFormer-master/data'r'E:/code/CDnetV2-pytorch-master-main/CDnetV2-pytorch-master-main/data/cloud/
        # self.root = '/media/xk/新加卷1/wwxdata'
        self.root = '/media/xk/新加卷1/sentinel'
        self.test_mode = test_mode

    def __len__(self):
        return len(self.file_name_list)

    def __getitem__(self, idx):
        t_resize = Resize([384, 384])

        if self.test_mode == 0:
            img_name_add = self.file_name_list[idx][:-1]
            img_name = self.file_name_list[idx]
            img_name = img_name.replace("\n", "")
            name = img_name
            # label_name = 'cloud/train/label/' + img_name[:-4] + '.png'
            # img_name = 'cloud/train/rgb/' + img_name
            # label_name = 'cloud_source/label/' + img_name[:-4] + '.png'
            # img_name = 'cloud_source/rgb/' + img_name
            # label_name = 'cloud_target/label/' + img_name[:-4] + '.png'
            # img_name = 'cloud_target/rgb/' + img_name
            label_name = 'train/labels/' + img_name[:-4] + '.png'
            img_name = 'train/img/' + img_name
        if self.test_mode == 1:
            img_name_add = self.file_name_list[idx][:-5]
            img_name = self.file_name_list[idx]
            name = img_name
            img_name = img_name.replace("\n", "")

            # label_name = 'cloud_source/label/' + img_name[:-4] + '.png'
            # img_name = 'cloud_source/rgb/' + img_name

            # label_name = 'cloud_target/label/' + img_name[:-4] + '.png'
            # img_name = 'cloud_target/rgb/' + img_name
            label_name = 'test/labels/' + img_name[:-4] + '.png'
            img_name = 'test/img/' + img_name
        image = Image.open(self.root + '/' + img_name)
        # image = Image.open('/home/wlx/pycharmproject/CDnetV2-pytorch-master-main/CDnetV2-pytorch-master-main/data/cloud/train/rgb/LC80070662014234LGN00_502_stdgamma.jpg')
        label = Image.open(self.root + '/' + label_name).convert("L")
        image = np.array(image)
        image = image/255.0

        label = np.array(label)
        label = label.reshape(384, 384, 1)
        label = np.transpose(label, [2,0,1])
        image = np.transpose(image, [2,0,1])
        img_10ch = image.astype(np.float32)
        label_1ch = label.astype(np.float32)
        # img_10ch = Image.fromarray((image).astype(np.uint8))
        # label_1ch = Image.fromarray(np.uint8(label))

        sample = {'image': img_10ch, 'mask': label_1ch, 'name': name}

        return sample
    #rgb/lc.jo